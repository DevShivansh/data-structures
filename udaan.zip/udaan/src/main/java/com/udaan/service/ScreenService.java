package com.udaan.service;

import com.udaan.entities.Screen;

public interface ScreenService {
	
	public boolean addScreen(Screen screen);

}
